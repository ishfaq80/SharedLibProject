package com.company.esb;

public class Utlis {

	public static String sayHello(String sayHelloTo) {
		   return "Hello " + sayHelloTo;
		  }
}
		